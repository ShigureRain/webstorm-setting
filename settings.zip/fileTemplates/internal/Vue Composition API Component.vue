<template>
  #[[$END$]]#
</template>

<script>

</script>


<style scoped${STYLE_LANG_ATTR}>

</style>