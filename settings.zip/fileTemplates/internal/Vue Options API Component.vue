<template>
  #[[$END$]]#
</template>

<script${SCRIPT_LANG_ATTR}>
#if($USE_DEFINE_COMPONENT)
import {defineComponent} from 'vue'

export default defineComponent({
name: "${COMPONENT_NAME}"
})
#elseif($USE_VUE_EXTEND)
import Vue from 'vue'

export default Vue.extend({
name: "${COMPONENT_NAME}"
})
#else
export default {
name: "${COMPONENT_NAME}"
}
#end
</script>

<style scoped${STYLE_LANG_ATTR}>

</style>